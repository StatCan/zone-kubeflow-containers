from abc import abstractmethod

import banff
from banff._common.src.testing.assert_helper import (
    _GeneralizedTester,
    get_control_dataset_path,
)


class _BanffProcTester(_GeneralizedTester):
    """Testing class generic to all Banff C procedures."""
    def __init__(self, **kwargs):
        # if `drop_columns is True`, configure to drop "by" variables
        if kwargs.get("drop_columns", False) is True:
            kwargs["drop_columns"] = self.parms.get("by", None)

        # always enable capturing
        self.parms["capture"] = True

        # initialize in case procedure call fails
        self.call = None

        super().__init__(**kwargs)

    def _action(self):
        """Call subclass procedure execution method, handle certain exceptions."""
        try:
            self.call = self._execute_proc()
        except banff.exceptions.ProcedureCError as e:
            self.c_return_code = e.return_code
        else:
            self.c_return_code = self.call.rc

    @abstractmethod
    def _execute_proc(self):
        """Call the Banff procedure.

        Call the procedure passing all parameters.
        If no exception occurs, populate the `ds_compare_list` attribute appropriately.
        Return the procedure call
        """

class DeterminTester(_BanffProcTester):
    """Wrapper for testing Deterministic procedure.

    Call this wrapper as you would call the procedure.  The additional test parameters
    allow various assertions to be ran on the output log contents or datasets.
    """
    def __init__(
            self,
            #### Test parameters
            msg_list_contains       = None,
            msg_list_contains_exact = None,
            expected_error_count    = 0,
            expected_warning_count  = 0,
            rc_should_be_zero       = True,
            round_data              = None,
            drop_columns            = True,
            upcase_columns          = False,
            expected_outdata        = None,
            expected_outstatus      = None,

            #### Banff parameters
            # USER C code parameters
            accept_negative    = None,
            no_by_stats        = None,
            edits              = None,
            unit_id            = None,
            by                 = None,

            # USER dataset references
            indata             = None,
            instatus           = None,
            outdata            = None,
            outstatus          = None,

            # Fancy New Options
            presort             = None,
            prefill_by_vars     = None,
            # OPTIONS
            trace               = None,
            **kwargs,
    ):
        self.parms = {}
        self.parms["accept_negative"]    = accept_negative
        self.parms["no_by_stats"]        = no_by_stats
        self.parms["edits"]              = edits
        self.parms["unit_id"]            = unit_id
        self.parms["by"]                 = by
        self.parms["indata"]             = get_control_dataset_path(indata)
        self.parms["instatus"]           = get_control_dataset_path(instatus)
        self.parms["outstatus"]          = outstatus
        self.parms["outdata"]            = outdata
        self.parms["presort"]             = presort
        self.parms["prefill_by_vars"]     = prefill_by_vars
        self.parms["trace"]               = trace
        self.parms.update(**kwargs)

        self._expected_outdata = get_control_dataset_path(expected_outdata)
        self._expected_outstatus = get_control_dataset_path(expected_outstatus)

        super().__init__(
            msg_list_contains=msg_list_contains,
            msg_list_contains_exact=msg_list_contains_exact,
            expected_error_count=expected_error_count,
            expected_warning_count=expected_warning_count,
            rc_should_be_zero=rc_should_be_zero,
            round_data=round_data,
            drop_columns=drop_columns,
            upcase_columns=upcase_columns,
        )

    def _execute_proc(self):
        call = banff.determin(
            **self.parms,
        )
        # create list of associated actual and expected output datasets
        self.ds_compare_list = [
            [call._outdata,   self._expected_outdata],
            [call._outstatus, self._expected_outstatus],
        ]
        return call

class DonorimpTester(_BanffProcTester):
    """Wrapper for testing Donor Imputation procedure.

    Call this wrapper as you would call the procedure.  The additional test parameters
    allow various assertions to be ran on the output log contents or datasets.
    """

    def __init__(
            self,
            #### Unit test parameters
            msg_list_contains       = None,
            msg_list_contains_exact = None,
            expected_error_count    = 0,
            expected_warning_count  = 0,
            rc_should_be_zero       = True,
            round_data              = None,
            drop_columns            = True,
            upcase_columns          = False,
            expected_outdata        = None,
            expected_outstatus      = None,
            expected_outdonormap    = None,
            expected_outmatching_fields = None,

            #### Banff parameters
            # USER C code parameters
            unit_id             = None,
            by                  = None,
            must_match          = None,
            data_excl_var       = None,
            rand_num_var        = None,
            random              = None,
            seed                = None,
            edits               = None,
            post_edits          = None,
            display_level       = None,
            accept_negative     = None,
            no_by_stats         = None,
            min_donors          = None,
            percent_donors      = None,
            n                   = None,
            eligdon             = None,
            n_limit             = None,
            mrl                 = None,
            # USER dataset references
            indata              = None,
            instatus            = None,
            outdata             = None,
            outstatus           = None,
            outdonormap         = None,
            outmatching_fields  = None,

            # Fancy New Options
            presort             = None,
            prefill_by_vars     = None,
            exclude_where_indata = None,
            # OPTIONS
            trace               = None,
            **kwargs,
    ):
        self.parms = {}
        self.parms["unit_id"]            = unit_id
        self.parms["by"]                 = by
        self.parms["must_match"]         = must_match
        self.parms["data_excl_var"]      = data_excl_var
        self.parms["rand_num_var"]       = rand_num_var
        self.parms["random"]             = random
        self.parms["seed"]               = seed
        self.parms["edits"]              = edits
        self.parms["post_edits"]         = post_edits
        self.parms["display_level"]      = display_level
        self.parms["accept_negative"]    = accept_negative
        self.parms["no_by_stats"]        = no_by_stats
        self.parms["min_donors"]         = min_donors
        self.parms["percent_donors"]     = percent_donors
        self.parms["n"]                  = n
        self.parms["eligdon"]            = eligdon
        self.parms["n_limit"]            = n_limit
        self.parms["mrl"]                = mrl
        self.parms["indata"]             = get_control_dataset_path(indata)
        self.parms["instatus"]           = get_control_dataset_path(instatus)
        self.parms["outdata"]            = outdata
        self.parms["outstatus"]          = outstatus
        self.parms["outdonormap"]        = outdonormap
        self.parms["outmatching_fields"] = outmatching_fields
        self.parms["presort"]             = presort
        self.parms["prefill_by_vars"]     = prefill_by_vars
        self.parms["exclude_where_indata"] = exclude_where_indata
        self.parms["trace"]               = trace
        self.parms.update(**kwargs)

        self._expected_outdata = get_control_dataset_path(expected_outdata)
        self._expected_outstatus = get_control_dataset_path(expected_outstatus)
        self._expected_outdonormap = get_control_dataset_path(expected_outdonormap)
        self._expected_outmatching_fields = get_control_dataset_path(expected_outmatching_fields)

        super().__init__(
            msg_list_contains=msg_list_contains,
            msg_list_contains_exact=msg_list_contains_exact,
            expected_error_count=expected_error_count,
            expected_warning_count=expected_warning_count,
            rc_should_be_zero=rc_should_be_zero,
            round_data=round_data,
            drop_columns=drop_columns,
            upcase_columns=upcase_columns,
        )

    def _execute_proc(self):
        call = banff.donorimp(
            **self.parms,
        )
        # create list of associated actual and expected output datasets
        self.ds_compare_list = [
            [call._outdata,   self._expected_outdata],
            [call._outstatus,   self._expected_outstatus],
            [call._outdonormap,   self._expected_outdonormap],
            [call._outmatching_fields, self._expected_outmatching_fields],
        ]
        return call

class EditstatTester(_BanffProcTester):
    """Wrapper for testing Edit Statistics procedure.

    Call this wrapper as you would call the procedure.  The additional test parameters
    allow various assertions to be ran on the output log contents or datasets.
    """

    def __init__(
            self,
            #### Unit test parameters
            msg_list_contains       = None,
            msg_list_contains_exact = None,
            expected_error_count    = 0,
            expected_warning_count  = 0,
            rc_should_be_zero       = True,
            round_data              = None,
            drop_columns            = True,
            upcase_columns          = False,
            expected_outedit_applic     = None,
            expected_outedit_status     = None,
            expected_outglobal_status   = None,
            expected_outk_edits_status  = None,
            expected_outedits_reduced   = None,
            expected_outvars_role       = None,

            #### Banff parameters
            # USER C code parameters
            accept_negative    = None,
            edits              = None,
            by                 = None,
            # USER dataset references
            indata             = None,
            outedit_applic     = None,
            outedit_status     = None,
            outglobal_status   = None,
            outk_edits_status  = None,
            outedits_reduced   = None,
            outvars_role       = None,

            # Fancy New Options
            presort             = None,
            # OPTIONS
            trace               = None,
            **kwargs,
    ):
        self.parms = {}
        self.parms["by"]                = by
        self.parms["edits"]             = edits
        self.parms["accept_negative"]   = accept_negative
        self.parms["indata"]            = get_control_dataset_path(indata)
        self.parms["outedit_applic"]    = outedit_applic
        self.parms["outedit_status"]    = outedit_status
        self.parms["outglobal_status"]  = outglobal_status
        self.parms["outk_edits_status"] = outk_edits_status
        self.parms["outedits_reduced"]  = outedits_reduced
        self.parms["outvars_role"]      = outvars_role
        self.parms["presort"]           = presort
        self.parms["trace"]             = trace
        self.parms.update(**kwargs)

        self._expected_outedit_applic = get_control_dataset_path(expected_outedit_applic)
        self._expected_outedit_status = get_control_dataset_path(expected_outedit_status)
        self._expected_outglobal_status = get_control_dataset_path(expected_outglobal_status)
        self._expected_outk_edits_status = get_control_dataset_path(expected_outk_edits_status)
        self._expected_outedits_reduced = get_control_dataset_path(expected_outedits_reduced)
        self._expected_outvars_role = get_control_dataset_path(expected_outvars_role)

        super().__init__(
            msg_list_contains=msg_list_contains,
            msg_list_contains_exact=msg_list_contains_exact,
            expected_error_count=expected_error_count,
            expected_warning_count=expected_warning_count,
            rc_should_be_zero=rc_should_be_zero,
            round_data=round_data,
            drop_columns=drop_columns,
            upcase_columns=upcase_columns,
        )

    def _execute_proc(self):
        call = banff.editstat(
            **self.parms,
        )
        # create list of associated actual and expected output datasets
        self.ds_compare_list = [
            [call._outedit_applic    , self._expected_outedit_applic,      {"drop_columns":None}],
            [call._outedit_status    , self._expected_outedit_status,      {"drop_columns":None}],
            [call._outglobal_status  , self._expected_outglobal_status,    {"drop_columns":None}],
            [call._outk_edits_status , self._expected_outk_edits_status,   {"drop_columns":None}],
            [call._outedits_reduced  , self._expected_outedits_reduced],
            [call._outvars_role      , self._expected_outvars_role,        {"drop_columns":None}],
        ]
        return call

class ErrorlocTester(_BanffProcTester):
    """Wrapper for testing Error Localization procedure.

    Call this wrapper as you would call the procedure.  The additional test parameters
    allow various assertions to be ran on the output log contents or datasets.
    """

    def __init__(
            self,
            #### Unit test parameters
            msg_list_contains       = None,
            msg_list_contains_exact = None,
            expected_error_count    = 0,
            expected_warning_count  = 0,
            rc_should_be_zero       = True,
            round_data              = None,
            drop_columns            = True,
            upcase_columns          = False,
            expected_outstatus      = None,
            expected_outreject      = None,

            #### Banff parameters
            # USER C code parameters
            unit_id         = None,
            by              = None,
            rand_num_var    = None,
            edits           = None,
            weights         = None,
            cardinality     = None,
            time_per_obs    = None,
            seed            = None,
            display_level   = None,
            accept_negative = None,
            no_by_stats     = None,
            # USER dataset references
            indata          = None,
            instatus        = None,
            outstatus       = None,
            outreject       = None,

            # Fancy New Options
            presort             = None,
            prefill_by_vars     = None,
            # OPTIONS
            trace               = None,
            **kwargs,
    ):
        self.parms = {}
        self.parms["unit_id"]            = unit_id
        self.parms["by"]                 = by
        self.parms["rand_num_var"]       = rand_num_var
        self.parms["edits"]              = edits
        self.parms["weights"]            = weights
        self.parms["cardinality"]        = cardinality
        self.parms["time_per_obs"]       = time_per_obs
        self.parms["seed"]               = seed
        self.parms["display_level"]      = display_level
        self.parms["accept_negative"]    = accept_negative
        self.parms["no_by_stats"]        = no_by_stats
        self.parms["indata"]             = get_control_dataset_path(indata)
        self.parms["instatus"]           = get_control_dataset_path(instatus)
        self.parms["outstatus"]          = outstatus
        self.parms["outreject"]          = outreject
        self.parms["presort"]             = presort
        self.parms["prefill_by_vars"]     = prefill_by_vars
        self.parms["trace"]               = trace
        self.parms.update(**kwargs)

        self._expected_outstatus = get_control_dataset_path(expected_outstatus)
        self._expected_outreject = get_control_dataset_path(expected_outreject)

        super().__init__(
            msg_list_contains=msg_list_contains,
            msg_list_contains_exact=msg_list_contains_exact,
            expected_error_count=expected_error_count,
            expected_warning_count=expected_warning_count,
            rc_should_be_zero=rc_should_be_zero,
            round_data=round_data,
            drop_columns=drop_columns,
            upcase_columns=upcase_columns,
        )

    def _execute_proc(self):
        call = banff.errorloc(
            **self.parms,
        )
        # create list of associated actual and expected output datasets
        self.ds_compare_list = [
            [call._outstatus, self._expected_outstatus],
            [call._outreject, self._expected_outreject],
        ]
        return call

class EstimatoTester(_BanffProcTester):
    """Wrapper for testing Estimator procedure.

    Call this wrapper as you would call the procedure.  The additional test parameters
    allow various assertions to be ran on the output log contents or datasets.
    """

    def __init__(
            self,
            #### Unit test parameters
            msg_list_contains       = None,
            msg_list_contains_exact = None,
            expected_error_count    = 0,
            expected_warning_count  = 0,
            rc_should_be_zero       = True,
            round_data              = None,
            drop_columns            = True,
            upcase_columns          = False,
            expected_outstatus      = None,
            expected_outdata        = None,
            expected_outacceptable  = None,
            expected_outest_ef      = None,
            expected_outest_lr      = None,
            expected_outest_parm    = None,
            expected_outrand_err    = None,

            #### Banff parameters
            # USER C code parameters
            unit_id             = None,
            by                  = None,
            data_excl_var       = None,
            hist_excl_var       = None,
            seed                = None,
            verify_specs        = None,
            accept_negative     = None,
            no_by_stats         = None,
            # USER dataset references
            indata              = None,
            instatus            = None,
            indata_hist         = None,
            inalgorithm         = None,
            inestimator         = None,
            instatus_hist       = None,
            outstatus           = None,
            outdata             = None,
            outacceptable       = None,
            outest_ef           = None,
            outest_lr           = None,
            outest_parm         = None,
            outrand_err         = None,

            # Fancy New Options
            presort             = None,
            prefill_by_vars     = None,
            exclude_where_indata = None,
            exclude_where_indata_hist = None,
            # OPTIONS
            trace               = None,
            **kwargs,
    ):
        self.parms = {}
        self.parms["unit_id"]            = unit_id
        self.parms["by"]                 = by
        self.parms["data_excl_var"]      = data_excl_var
        self.parms["hist_excl_var"]      = hist_excl_var
        self.parms["seed"]               = seed
        self.parms["verify_specs"]       = verify_specs
        self.parms["accept_negative"]    = accept_negative
        self.parms["no_by_stats"]        = no_by_stats
        self.parms["indata"]             = get_control_dataset_path(indata)
        self.parms["instatus"]           = get_control_dataset_path(instatus)
        self.parms["indata_hist"]        = get_control_dataset_path(indata_hist)
        self.parms["inalgorithm"]        = get_control_dataset_path(inalgorithm)
        self.parms["inestimator"]        = get_control_dataset_path(inestimator)
        self.parms["instatus_hist"]      = get_control_dataset_path(instatus_hist)
        self.parms["outstatus"]          = outstatus
        self.parms["outdata"]            = outdata
        self.parms["outacceptable"]      = outacceptable
        self.parms["outest_ef"]          = outest_ef
        self.parms["outest_lr"]          = outest_lr
        self.parms["outest_parm"]        = outest_parm
        self.parms["outrand_err"]        = outrand_err
        self.parms["presort"]             = presort
        self.parms["prefill_by_vars"]     = prefill_by_vars
        self.parms["exclude_where_indata"] = exclude_where_indata
        self.parms["exclude_where_indata_hist"] = exclude_where_indata_hist
        self.parms["trace"]               = trace
        self.parms.update(**kwargs)

        self._expected_outstatus = get_control_dataset_path(expected_outstatus)
        self._expected_outdata = get_control_dataset_path(expected_outdata)
        self._expected_outacceptable = get_control_dataset_path(expected_outacceptable)
        self._expected_outest_ef = get_control_dataset_path(expected_outest_ef)
        self._expected_outest_lr = get_control_dataset_path(expected_outest_lr)
        self._expected_outest_parm = get_control_dataset_path(expected_outest_parm)
        self._expected_outrand_err = get_control_dataset_path(expected_outrand_err)

        super().__init__(
            msg_list_contains=msg_list_contains,
            msg_list_contains_exact=msg_list_contains_exact,
            expected_error_count=expected_error_count,
            expected_warning_count=expected_warning_count,
            rc_should_be_zero=rc_should_be_zero,
            round_data=round_data,
            drop_columns=drop_columns,
            upcase_columns=upcase_columns,
        )

    def _execute_proc(self):
        call = banff.estimato(
            **self.parms,
        )
        # create list of associated actual and expected output datasets
        self.ds_compare_list = [
                    [call._outstatus,     self._expected_outstatus],
                    [call._outdata,       self._expected_outdata],
                    [call._outacceptable, self._expected_outacceptable,    {"drop_columns":None}],
                    [call._outest_ef,     self._expected_outest_ef,        {"drop_columns":None}],
                    [call._outest_lr,     self._expected_outest_lr,        {"drop_columns":None}],
                    [call._outest_parm,   self._expected_outest_parm,      {"drop_columns":None}],
                    [call._outrand_err,   self._expected_outrand_err,      {"drop_columns":None}],
        ]
        return call

class MassimpuTester(_BanffProcTester):
    """Wrapper for testing Massimputation procedure.

    Call this wrapper as you would call the procedure.  The additional test parameters
    allow various assertions to be ran on the output log contents or datasets.
    """

    def __init__(
            self,
            #### Unit test parameters
            msg_list_contains       = None,
            msg_list_contains_exact = None,
            expected_error_count    = 0,
            expected_warning_count  = 0,
            rc_should_be_zero       = True,
            round_data              = None,
            drop_columns            = True,
            upcase_columns          = False,
            expected_outdata        = None,
            expected_outstatus      = None,
            expected_outdonormap    = None,

            #### Banff parameters
            # USER C code parameters
            accept_negative    = None,
            no_by_stats        = None,
            random             = None,
            mrl                = None,
            percent_donors     = None,
            min_donors         = None,
            n_limit            = None,
            seed               = None,
            unit_id            = None,
            by                 = None,
            must_impute        = None,
            must_match         = None,
            # USER dataset references
            indata             = None,
            outdata            = None,
            outdonormap        = None,

            # Fancy New Options
            presort             = None,
            # OPTIONS
            trace               = None,
            **kwargs,
    ):
        self.parms = {}
        self.parms["accept_negative"]    = accept_negative
        self.parms["no_by_stats"]        = no_by_stats
        self.parms["random"]             = random
        self.parms["mrl"]                = mrl
        self.parms["percent_donors"]     = percent_donors
        self.parms["min_donors"]         = min_donors
        self.parms["n_limit"]            = n_limit
        self.parms["seed"]               = seed
        self.parms["unit_id"]            = unit_id
        self.parms["by"]                 = by
        self.parms["must_impute"]        = must_impute
        self.parms["must_match"]         = must_match
        self.parms["indata"]             = get_control_dataset_path(indata)
        self.parms["outdata"]            = outdata
        self.parms["outdonormap"]        = outdonormap
        self.parms["presort"]             = presort
        self.parms["trace"]               = trace
        self.parms.update(**kwargs)

        self._expected_outdata = get_control_dataset_path(expected_outdata)
        self._expected_outstatus = get_control_dataset_path(expected_outstatus)
        self._expected_outdonormap = get_control_dataset_path(expected_outdonormap)

        super().__init__(
            msg_list_contains=msg_list_contains,
            msg_list_contains_exact=msg_list_contains_exact,
            expected_error_count=expected_error_count,
            expected_warning_count=expected_warning_count,
            rc_should_be_zero=rc_should_be_zero,
            round_data=round_data,
            drop_columns=drop_columns,
            upcase_columns=upcase_columns,
        )

    def _execute_proc(self):
        call = banff.massimpu(
            **self.parms,
        )
        # create list of associated actual and expected output datasets
        self.ds_compare_list = [
                    [call._outdata,   self._expected_outdata],
                    [call._outstatus, self._expected_outstatus],
                    [call._outdonormap,  self._expected_outdonormap],
        ]
        return call

class OutlierTester(_BanffProcTester):
    """Wrapper for testing Outlier procedure.

    Call this wrapper as you would call the procedure.  The additional test parameters
    allow various assertions to be ran on the output log contents or datasets.
    """

    def __init__(
            self,
            #### Unit test parameters
            msg_list_contains       = None,
            msg_list_contains_exact = None,
            expected_error_count    = 0,
            expected_warning_count  = 0,
            rc_should_be_zero       = True,
            round_data              = None,
            drop_columns            = True,
            upcase_columns          = False,
            expected_outstatus      = None,
            expected_outstatus_detailed = None,
            expected_outsummary     = None,

            #### Banff parameters
            # USER C code parameters
            unit_id             = None,
            weight              = None,
            by                  = None,
            var                 = None,
            with_var            = None,
            accept_negative     = None,
            no_by_stats         = None,
            accept_zero         = None,
            outlier_stats       = None,
            beta_e              = None,
            beta_i              = None,
            exponent            = None,
            mdm                 = None,
            mei                 = None,
            mii                 = None,
            start_centile       = None,
            min_obs             = None,
            method              = None,
            side                = None,
            sigma               = None,
            lower_p             = None,
            upper_p             = None,
            # USER dataset references
            indata              = None,
            indata_hist         = None,
            outstatus           = None,
            outstatus_detailed  = None,
            outsummary          = None,

            # Fancy New Options
            presort             = None,
            exclude_where_indata = None,
            # OPTIONS
            trace               = None,
            **kwargs,
    ):
        self.parms = {}
        self.parms["unit_id"]             = unit_id
        self.parms["weight"]              = weight
        self.parms["by"]                  = by
        self.parms["var"]                 = var
        self.parms["with_var"]            = with_var
        self.parms["accept_negative"]     = accept_negative
        self.parms["no_by_stats"]         = no_by_stats
        self.parms["accept_zero"]         = accept_zero
        self.parms["outlier_stats"]       = outlier_stats
        self.parms["beta_e"]              = beta_e
        self.parms["beta_i"]              = beta_i
        self.parms["exponent"]            = exponent
        self.parms["mdm"]                 = mdm
        self.parms["mei"]                 = mei
        self.parms["mii"]                 = mii
        self.parms["start_centile"]       = start_centile
        self.parms["min_obs"]             = min_obs
        self.parms["method"]              = method
        self.parms["side"]                = side
        self.parms["sigma"]               = sigma
        self.parms["lower_p"]             = lower_p
        self.parms["upper_p"]             = upper_p
        self.parms["indata"]              = get_control_dataset_path(indata)
        self.parms["indata_hist"]         = get_control_dataset_path(indata_hist)
        self.parms["outstatus"]           = outstatus
        self.parms["outstatus_detailed"]  = outstatus_detailed
        self.parms["outsummary"]          = outsummary
        self.parms["presort"]             = presort
        self.parms["exclude_where_indata"] = exclude_where_indata
        self.parms["trace"]               = trace
        self.parms.update(**kwargs)

        self._expected_outstatus = get_control_dataset_path(expected_outstatus)
        self._expected_outstatus_detailed = get_control_dataset_path(expected_outstatus_detailed)
        self._expected_outsummary = get_control_dataset_path(expected_outsummary)

        super().__init__(
            msg_list_contains=msg_list_contains,
            msg_list_contains_exact=msg_list_contains_exact,
            expected_error_count=expected_error_count,
            expected_warning_count=expected_warning_count,
            rc_should_be_zero=rc_should_be_zero,
            round_data=round_data,
            drop_columns=drop_columns,
            upcase_columns=upcase_columns,
        )

    def _execute_proc(self):
        call = banff.outlier(
            **self.parms,
        )
        # create list of associated actual and expected output datasets
        self.ds_compare_list = [
                    [call._outstatus,     self._expected_outstatus],
                    [call._outstatus_detailed,     self._expected_outstatus_detailed],
                    [call._outsummary,    self._expected_outsummary,   {"drop_columns":None}],
        ]
        return call

class ProrateTester(_BanffProcTester):
    """Wrapper for testing Prorate procedure.

    Call this wrapper as you would call the procedure.  The additional test parameters
    allow various assertions to be ran on the output log contents or datasets.
    """

    def __init__(
            self,
            #### Unit test parameters
            msg_list_contains       = None,
            msg_list_contains_exact = None,
            expected_error_count    = 0,
            expected_warning_count  = 0,
            rc_should_be_zero       = True,
            round_data              = None,
            drop_columns            = True,
            upcase_columns          = False,
            expected_outdata        = None,
            expected_outstatus      = None,
            expected_outreject      = None,

            #### Banff parameters
            # USER C code parameters
            accept_negative    = None,
            no_by_stats        = None,
            verify_edits       = None,
            lower_bound        = None,
            upper_bound        = None,
            decimal            = None,
            edits              = None,
            method             = None,
            modifier           = None,
            unit_id            = None,
            by                 = None,
            # USER dataset references
            indata             = None,
            instatus           = None,
            outstatus          = None,
            outdata            = None,
            outreject          = None,

            # Fancy New Options
            presort             = None,
            prefill_by_vars     = None,
            # OPTIONS
            trace               = None,
            **kwargs,
    ):
        self.parms = {}
        self.parms["accept_negative"]    = accept_negative
        self.parms["no_by_stats"]        = no_by_stats
        self.parms["verify_edits"]       = verify_edits
        self.parms["lower_bound"]        = lower_bound
        self.parms["upper_bound"]        = upper_bound
        self.parms["decimal"]            = decimal
        self.parms["edits"]              = edits
        self.parms["method"]             = method
        self.parms["modifier"]           = modifier
        self.parms["unit_id"]            = unit_id
        self.parms["by"]                 = by
        self.parms["indata"]             = get_control_dataset_path(indata)
        self.parms["instatus"]           = get_control_dataset_path(instatus)
        self.parms["outstatus"]          = outstatus
        self.parms["outdata"]            = outdata
        self.parms["outreject"]          = outreject
        self.parms["presort"]             = presort
        self.parms["prefill_by_vars"]     = prefill_by_vars
        self.parms["trace"]               = trace
        self.parms.update(**kwargs)

        self._expected_outstatus = get_control_dataset_path(expected_outstatus)
        self._expected_outdata = get_control_dataset_path(expected_outdata)
        self._expected_outreject = get_control_dataset_path(expected_outreject)

        super().__init__(
            msg_list_contains=msg_list_contains,
            msg_list_contains_exact=msg_list_contains_exact,
            expected_error_count=expected_error_count,
            expected_warning_count=expected_warning_count,
            rc_should_be_zero=rc_should_be_zero,
            round_data=round_data,
            drop_columns=drop_columns,
            upcase_columns=upcase_columns,
        )

    def _execute_proc(self):
        call = banff.prorate(
            **self.parms,
        )
        # create list of associated actual and expected output datasets
        self.ds_compare_list = [
                    [call._outstatus, self._expected_outstatus],
                    [call._outdata,   self._expected_outdata],
                    [call._outreject, self._expected_outreject],
        ]
        return call

class VerifyedTester(_BanffProcTester):
    """Wrapper for testing Verify Edits procedure.

    Call this wrapper as you would call the procedure.  The additional test parameters
    allow various assertions to be ran on the output log contents or datasets.
    """

    def __init__(
            self,
            #### Unit test parameters
            msg_list_contains       = None,
            msg_list_contains_exact = None,
            expected_error_count    = 0,
            expected_warning_count  = 0,
            rc_should_be_zero       = True,

            #### Banff parameters
            # USER C code parameters
            accept_negative    = None,
            extremal           = None,
            imply              = None,
            edits              = None,

            # OPTIONS
            trace               = None,
            **kwargs,
    ):
        self.parms = {}
        self.parms["accept_negative"]    = accept_negative
        self.parms["extremal"]           = extremal
        self.parms["imply"]              = imply
        self.parms["edits"]              = edits
        self.parms["trace"]               = trace
        self.parms.update(**kwargs)

        super().__init__(
            msg_list_contains       = msg_list_contains,
            msg_list_contains_exact = msg_list_contains_exact,
            expected_error_count    = expected_error_count,
            expected_warning_count  = expected_warning_count,
            rc_should_be_zero       = rc_should_be_zero,
            drop_columns            = False,
        )

    def _execute_proc(self):
        call = banff.verifyed(
            **self.parms,
        )
        return call
