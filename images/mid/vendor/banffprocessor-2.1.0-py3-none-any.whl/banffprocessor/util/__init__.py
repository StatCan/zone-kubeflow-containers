"""Utility module with modules for data conversion, storage and otherwise."""
