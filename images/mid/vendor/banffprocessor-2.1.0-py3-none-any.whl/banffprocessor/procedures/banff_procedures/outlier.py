"""Wrapper class for calling the Outlier Banff proc and processing the results for a Processor job step."""
from typing import ClassVar

import banff.exceptions
from banff import outlier
from banff._log import log_levels

# Import must be absolute in order to ensure all modules reference the same global _c_handlers
import banffprocessor.processor_logger as plg
from banffprocessor.exceptions import MetadataError, ProcessorInputParameterError
from banffprocessor.metadata.models.outlierspecs import Outlierspecs
from banffprocessor.nls import _
from banffprocessor.procedures import factory
from banffprocessor.processor_data import ProcessorData
from banffprocessor.util.dataset import table_empty

# Setup local log for processor module specifically
log_lcl = plg.get_processor_child_logger("outlier")

# Required Metadata files = "outlierspecs"
# Optional Metdata files = "varlists"

class Outlier:
    """Implements the Outlier Banff procedure as a `:class:banffprocessor.procedures.procedure_interface`."""

    output_tables: ClassVar[tuple[str]] = ("outlier_status", "outsummary")
    registered_proc_names: ClassVar[list[str]] = ["outlier"]

    @classmethod
    def execute(cls, processor_data: ProcessorData) -> int:
        """Execute the banff.outlier call, and returns the results."""
        # alias the param name to shorten references
        bp = processor_data
        job_step = bp.current_job_step

        outlier_spec: Outlierspecs = bp.metaobjects.get_specs_obj(Outlierspecs, job_step.specid)
        if(outlier_spec is None):
            msg = _("No OutlierSpecs records were found with specid {}.").format(job_step.specid)
            log_lcl.exception(msg)
            raise MetadataError(msg)

        varlist = []
        with_varlist = []
        if(outlier_spec.varid is not None):
            varlist = bp.metaobjects.get_varlist_fieldids(outlier_spec.varid)
            if(not varlist):
                msg = _("No varlist records found under varid {}.").format(outlier_spec.varid)
                log_lcl.exception(msg)
                raise MetadataError(msg)
        if(outlier_spec.withid is not None):
            with_varlist = bp.metaobjects.get_varlist_fieldids(outlier_spec.withid)
            if(not with_varlist):
                msg = _("No varlist records found under varid {}.").format(outlier_spec.withid)
                log_lcl.exception(msg)
                raise MetadataError(msg)

        indata_hist_param = None
        if outlier_spec.isHistMethod:
            indata_hist_param = bp.get_dataset("indata_hist")
            if indata_hist_param is None:
                msg = _("Outlierspecs indicated this step uses a historical trend method "
                        "but the historic data file was not found or otherwise unable to be loaded.")
                log_lcl.exception(msg)
                raise ProcessorInputParameterError(msg)

        # Imputed_File should always have data by this point, but we'll make sure to pass None
        # instead of an empty table to the banff call just to make sure we don't pass an empty table
        imputed_file = bp.get_dataset("imputed_file")

        # Form our Banff call
        try:
            banff_call = outlier(
                unit_id=bp.input_params.unit_id,
                weight=outlier_spec.weight,
                by=" ".join(bp.by_varlist) if bp.by_varlist else None,
                var=" ".join(varlist) if varlist else None,
                with_var=" ".join(with_varlist) if with_varlist else None,
                no_by_stats=bp.input_params.no_by_stats,
                presort=True,
                # Not supposed to provide these as False, only True or None
                accept_negative=job_step.acceptnegative,
                accept_zero=outlier_spec.acceptzero,
                beta_e=outlier_spec.betae,
                beta_i=outlier_spec.betai,
                exponent=outlier_spec.exponent,
                mdm=outlier_spec.mdm,
                mei=outlier_spec.mei,
                mii=outlier_spec.mii,
                start_centile=outlier_spec.startcentile,
                min_obs=outlier_spec.minobs,
                method=outlier_spec.method,
                side=outlier_spec.side,
                sigma=outlier_spec.sigma,
                lower_p=outlier_spec.lowerp,
                upper_p=outlier_spec.upperp,
                exclude_where_indata=bp.metaobjects.get_expression(outlier_spec.dataexclvar),
                indata=imputed_file if imputed_file is not None and not table_empty(imputed_file) else None,
                indata_hist=indata_hist_param,
                # Specify to get extra data in outstatus, used for validation in tests
                outlier_stats=True,
                outstatus="pyarrow",
                outstatus_detailed="pyarrow" if bp.output_required("outlier_status") else False,
                outsummary="pyarrow" if bp.output_required("outsummary") else False,
                # We want everything captured while an input param configures the handlers
                # which indirectly filter.
                trace=log_levels.NOTSET,
                # Note that capture=None will supress console output in new version so use False or omit
                logger=log_lcl,
                _BP_c_log_handlers=plg.get_c_handlers(),
            )
        except banff.exceptions.ProcedureCError as e:
            msg = _("An error occured during execution of this procedure.")
            log_lcl.exception(msg)
            return e.return_code # Get the return code from the exception

        bp.outstatus = banff_call.outstatus

        # Will only have values if they were requested
        if(banff_call.outstatus_detailed):
            bp.set_dataset("outlier_status", banff_call.outstatus_detailed)
        if(banff_call.outsummary):
            bp.set_dataset("outsummary", banff_call.outsummary)

        return banff_call.rc

def register(factory: factory) -> None:
    """Register this procedure class in the Banff processor procedure factory."""
    factory.register(Outlier.registered_proc_names, Outlier)
