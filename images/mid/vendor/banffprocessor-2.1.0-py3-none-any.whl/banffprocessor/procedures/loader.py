"""Load plugin files from a defined location as python modules."""
import sys
from importlib.util import module_from_spec, spec_from_file_location
from logging import Logger
from pathlib import Path

from banffprocessor.nls import _
from banffprocessor.procedures import factory

# Module name to register user plugins under
_USER_MODULE_NAME = "plugins"

def load_plugins(plugin_dir: str | Path, log: Logger) -> None:
    """Load plugins from the plugin directory.

    Load all python files that include a register function from `plugin_dir`
    as modules and call these register functions to load plugin classes.

    :param plugin_dir: The directory where the plugin files to load are located
    :type plugin_dir: str | Path
    :param log: A logger to report progress of loading via debug messages
    :type log: Logger
    :raises ValueError: If `plugin_dir` is an empty string or None
    """
    if not plugin_dir:
        msg = _("plugin_dir argument was empty or None.")
        log.debug(msg)
        raise ValueError(msg)

    plugin_dir = Path(plugin_dir)
    log.debug(_("Loading plugins from plugin directory {}").format(plugin_dir.resolve()))

    if not plugin_dir.is_dir():
        msg = _("Plugin directory is not an existing directory.")
        raise ValueError(msg)

    # Get a list of all the modules in the specified folder, non-recursively
    module_files = plugin_dir.resolve().glob("*.py")

    for file in module_files:
        if file.is_file() and not file.name.startswith("_"):
            log.debug(_("Loading file: {}").format(file))

            # Module name is just filename without extension
            module_name = f"{_USER_MODULE_NAME}.{file.stem}"

            log.debug(_("Loading as module_name: {}").format(module_name))
            spec = spec_from_file_location(module_name, file)

            plugin = module_from_spec(spec)
            sys.modules[module_name] = plugin
            spec.loader.exec_module(plugin)
            if hasattr(plugin, "register"):
                log.debug(_("Registering plugin..."))
                plugin.register(factory)
            else:
                log.debug(_("Plugin was not registered: missing register function"))

    log.debug(_("Plugin loading complete."))
